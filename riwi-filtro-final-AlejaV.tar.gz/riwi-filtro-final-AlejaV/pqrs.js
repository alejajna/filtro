
function enviar() {
    const pqrSel = document.querySelector("#pqrSel");
    const pqrEmail = document.querySelector("#pqrEmail");
    const pqrMen = document.querySelector("#pqrMen");

    pqr = {
        type: pqrSel.value,
        email: pqrEmail.value,
        message: pqrMen.value
    }
    
    fetch("http://localhost:3000/pqrs", {
        method: 'POST',
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(pqr)
    })
    .then(response => {
        return response.json()
    }).then(data => {
        console.log(data) & location.reload();
    })
}