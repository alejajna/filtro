// traer el input 
const email = document.querySelector("#email");
const password = document.querySelector("#password");

// condicional
function iniciosesione() {
    if(email.value != "") {
        email.classList.add("is-valid")
        email.classList.remove("is-invalid");
    }
    else {
        email.classList.add("is-invalid")
        email.classList.remove("is-valid");
    }

    if(password.value != "") {
        password.classList.add("is-valid")
        password.classList.remove("is-invalid")
    }
    else {
        password.classList.add("is-invalid")
        password.classList.remove("is-valid")
    }

    fetch("http://localhost:3000/admin")
    .then(response => {
        return response.json()
    }).then(data => {
        data.forEach(function (element) {

            if(email.value == element.email && password.value == element.password) {
                location.href = "admin/index.html"
                localStorage.setItem("name", element.name)
                }
                 else {
                    alert("USUARIO O CONTRASEÑA INVALIDO");
                }
        })
    })
}
