let name2 = localStorage.getItem('name')
document.querySelector('#userAdmin').innerHTML = name2

const admin = document.querySelector("#admin");

let resultado = fetch("http://localhost:3000/admin")
.then(response => {
    return response.json()
}).then(data => {
    data.forEach(function (element) {
        const tr = document.createElement("tr");
        localStorage.setItem("id", element.id);
        localStorage.setItem('name', element.name);
        localStorage.setItem('email', element.email);

        tr.innerHTML = `
            <td>${element.id}</td>
            <td>${element.name}</td>
            <td>${element.email}</td>
            <td>
                <button onclick= "detalles1('${element.id}')" class="btn btn-sm btn-info">Detalles</button>
                <button onclick= "editar1('${element.id}')" class="btn btn-sm btn-warning">Editar</button>
                <button onclick= "eliminar1('${element.id}')" class="btn btn-sm btn-danger">Eliminar</button>
            </td>`

        admin.appendChild(tr);
    })
})

function detalles1(id) {

    fetch("http://localhost:3000/admin/" + id)
    .then(response => {
        return response.json()
    }).then(data => {
        window.confirm(`
        Name: ${data.name}
        Email: ${data.email}
        Password: ${data.password}`)
    })
}

function crear() {
    const name = document.querySelector("#name");
    const email = document.querySelector("#email");
    const password = document.querySelector("#password");

    administrador = {
        name: name.value,
        email: email.value,
        password: password.value
    }

    let emailLocal = localStorage.getItem("email")
// crear usuario
    if(emailLocal != email.value) {
        fetch("http://localhost:3000/admin" , 
            {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(administrador)
        })
        .then(response => {
            return response.json()
        }).then(data => {
            console.log(data) & location.reload();
        })
    }

    else {
        alert("Este correo ya existe ")
    }

}

function eliminar1(id) {
// eliminar id
    fetch("http://localhost:3000/admin/" + id, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        return response.json()
    }).then(data => {
        console.log(data) & location.reload();
    })
}
