let name2 = localStorage.getItem('name')
document.querySelector('#userAdmin').innerHTML = name2

const pqrs = document.querySelector("#pqrs");

let resultado = fetch("http://localhost:3000/pqrs")
.then(response => {
    return response.json()
}).then(data => {
    data.forEach(function (element) {
        const tr = document.createElement("tr");

        tr.innerHTML = `                                    
            <td>${element.id}</td>
            <td>${element.type}</td>
            <td>${element.email}</td>
            <td>
                ${element.message}
            </td>
            <td>
                <button onclick= "eliminar1('${element.id}')" class="btn btn-sm btn-danger">Eliminar</button>
            </td>`

        pqrs.appendChild(tr)
    })
})

function eliminar1(id) {

    fetch("http://localhost:3000/pqrs/" + id, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        }
    }).then(response => {
        return response.json()
    }).then(data => {
        console.log(data) & location.reload();
    })
}

let resultados = fetch("http://localhost:3000/admin")
.then(response => {
    return response.json()
}).then(data => {
    data.forEach(function (element) {
        localStorage.setItem('name', element.name)
    })
})
