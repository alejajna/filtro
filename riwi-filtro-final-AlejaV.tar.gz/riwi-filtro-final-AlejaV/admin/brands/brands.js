let name2 = localStorage.getItem('name')
document.querySelector('#userAdmin').innerHTML = name2

const brands = document.querySelector("#brands"); 

let resultado = fetch("http://localhost:3000/marcas")
.then(response => {
    return response.json()
}).then(data => {
    data.forEach(function (element) {
        const tr = document.createElement("tr")
        localStorage.setItem("id", element.id)
        localStorage.setItem("name", element.name)

        tr.innerHTML = `
            <td>${element.id}</td>
            <td><img width="100px" src="${element.logo}" alt=""></td>
            <td>${element.name}</td>
            <td>${element.local}</td>
            <td>${element.floor}</td>
            <td>
                ${element.horarios}
            </td>
            <td>
                <a target= "_blank" href="${element.website}">${element.website}</a>
            </td>
            <td>
                <button onclick= "detalles1('${element.id}')" class="btn btn-sm btn-info">Detalles</button>
                <button onclick= "editar('${element.id}')" class="btn btn-sm btn-warning">Editar</button>
                <button onclick= "eliminar1('${element.id}')" class="btn btn-sm btn-danger">Eliminar</button>
            </td>`

        brands.appendChild(tr)
    })
})

function detalles1(id) {

    fetch("http://localhost:3000/marcas/" + id)
    .then(response => {
        return response.json()
    }).then(data => {
        window.confirm(`
    Name: ${data.name}
    Local: ${data.local}
    Floor: ${data.floor}
    Schedules: ${data.horarios}
    Description: ${data.description}
    Website: ${data.website}`)
    })
}

function crear() {
    const name = document.querySelector("#name");
    const local = document.querySelector("#local");
    const floor = document.querySelector("#floor");
    const horarios = document.querySelector("#horarios");
    const logo = document.querySelector("#logo");
    const website = document.querySelector("#website");
    const description = document.querySelector("#description");

    marca = {
        name: name.value,
        local: local.value,
        floor: floor.value,
        horarios: horarios.value,
        logo: logo.value,
        website: website.value,
        description: description.value
    }

    let nameLocal = localStorage.getItem("name")

    if(name.value != nameLocal ) {
        fetch("http://localhost:3000/marcas" , 
            {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(marca)
        })
        .then(response => {
            return response.json()
        }).then(data => {
            console.log(data) & location.reload();
        })
    }
    else {
        alert("Ya existe una empresa con ese nombre")
    }

}

function eliminar1(id) {

    fetch("http://localhost:3000/marcas/" + id, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => {
        return response.json()
    }).then(data => {
        console.log(data) & location.reload();
    })
}

let resultados = fetch("http://localhost:3000/marcas")
.then(response => {
    return response.json()
}).then(data => {
    data.forEach(function (element) {
        localStorage.setItem('name', element.name)
    })
})

