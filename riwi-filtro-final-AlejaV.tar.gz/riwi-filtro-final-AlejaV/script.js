//traer del html con la clase row
const row = document.querySelector(".row");

const resultado = fetch("http://localhost:3000/marcas")
.then(response => {
    return response.json()
}).then(data => {
    // recorrer el objeto
    data.forEach(function (element) {
        const col = document.createElement("div");//crear div para añadir las clases
        col.classList.add("col-md-6", "col-lg-3", "d-flex", "align-items-stretch", "mb-5", "mb-lg-0")
        localStorage.setItem("id", element.id)// obtener el id
        // todo lo que vamos a imprimir va a estar dentro de la col
        col.innerHTML = `
            <div class="icon-box mt-5" data-aos="fade-up" data-aos-delay="100">
                <img src="${element.logo}" class="img-fluid" alt="">
                <h4 class="title"><a href="">${element.name}</a></h4>
                <p class="description">${element.description}</p>
                <br>
                <button onclick= "detalles('${element.id}')" class="btn btn-primary w-100 btn-sm">Detalles</button>
            </div>`

        row.appendChild(col)
    })
})

function detalles(id) {

    fetch("http://localhost:3000/marcas/" + id)
    .then(response => {
        return response.json()
    }).then(data => {
        //imprimir desde el boton de detalles
        window.confirm(`
        Name: ${data.name}
        Local: ${data.local}
        Floor: ${data.floor}
        Schedules: ${data.horarios}
        Website: ${data.website}`)
    })
}